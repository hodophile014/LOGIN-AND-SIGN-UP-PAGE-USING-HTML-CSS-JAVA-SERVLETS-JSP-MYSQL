package com.registration;
import java.sql.ResultSet;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.RequestDispatcher;
/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uemail = request.getParameter("username");
		String upwd = request.getParameter("password");
		HttpSession session = request.getSession();
		RequestDispatcher dis = null;
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 String URL = "jdbc:mysql://localhost:3306/company";
            String User = "root";
            String Password = "Himanshi14";

		conn = DriverManager.getConnection(URL,User,Password);
		PreparedStatement pst = conn.prepareStatement("select * from users where uemail=? and upwd=?");
		pst.setString(1, uemail);
		pst.setString(2, upwd);
		ResultSet rs = pst.executeQuery();
		if(rs.next()) {
			session.setAttribute("username", rs.getString("uname"));
			dis = request.getRequestDispatcher("index.jsp");
			
		}
		else {
			request.setAttribute("status", "failed");
			dis = request.getRequestDispatcher("login.jsp");
		}
		dis.forward(request, response);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
