package com.registration;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
//import java.io.PrintWriter;
import java.sql.DriverManager;
@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname = request.getParameter("username");
		String email = request.getParameter("email");
		String upwd = request.getParameter("password");
		
		String umobile = request.getParameter("contact");
		RequestDispatcher dis = null;
		Connection conn=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 String URL = "jdbc:mysql://localhost:3306/company";
             String User = "root";
             String Password = "Himanshi14";

		conn = DriverManager.getConnection(URL,User,Password);
			PreparedStatement pst = conn.prepareStatement("insert into users(uname,upwd,uemail,umobile) values(?,?,?,?)");
			pst.setString(1, uname);
			pst.setString(2, upwd);
			pst.setString(3, email);
			pst.setString(4, umobile);
			int row = pst.executeUpdate();
			dis = request.getRequestDispatcher("signup.jsp");
			if(row > 0) {
				request.setAttribute("status", "success");
				}
			else {
				request.setAttribute("status", "failed");
			}
			dis.forward(request, response);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	
	}

}
